# ANIMAL DASH — Art Upgrade Development Progress

Roadmap: Stage 0 inspection → 1 Pug → 2 other four animals → 3 Stadium → 4 Arena → 5 obstacles & power-ups →
6 animations & VFX → 7 lighting/materials/polish → 8 optimisation & final QA.
Each stage ends with a tested, integrated result and **waits for approval** before the next stage starts.

| Stage | Status | Approved |
| --- | --- | --- |
| 0 — Inspection & backup | ✅ Complete (2026-11-24) | ⏳ awaiting approval |
| 1 — Pug character (Blender → GLB) | Not started | |
| 2 — Husky, Rottweiler, Orange Cat, Black Cat | Not started | |
| 3 — Stadium Sprint environment | Not started | |
| 4 — Crazy Obstacle Arena environment | Not started | |
| 5 — Obstacle & power-up assets | Not started | |
| 6 — Animations & VFX | Not started | |
| 7 — Lighting, materials & polish | Not started | |
| 8 — Optimisation & final QA | Not started | |

---

## Stage 0 — Project inspection and backup (complete)

### Existing game architecture
* **Client:** TypeScript + Vite, **raw WebGL2** renderer (`client/src/engine`): forward lighting, 2048² PCF shadow map,
  hemisphere ambient, rim light, fog, ACES tonemapping, instancing, frustum culling, particles.
* **Characters today:** procedural meshes built in code (`characters/animalModels.ts`), a fixed 17-bone rigid hierarchy
  (each bone owns a mesh), animated procedurally by `animations/animator.ts` (idle, run, jump, land, slide, stumble,
  knockdown, recover, knockback, pit fall, exhaustion, 4 victory styles). Cosmetics attach to head/body bones.
* **Environments today:** generated in code from the track path (`tracks/trackScene.ts`); obstacles and items in
  `obstacles/obstacleRenderer.ts` and `items/itemRenderer.ts`.
* **Gameplay:** deterministic shared simulation (`shared/src`), authoritative Colyseus server. **Visuals are fully
  decoupled from gameplay** — collisions use track-space data, never mesh geometry — so art can be replaced without
  touching mechanics.

### Tools available
| Tool | Result |
| --- | --- |
| Blender | **5.3.0** installed at `C:\Program Files\Blender Foundation\Blender 5.3\blender.exe` (not on PATH; scripts call it by full path) |
| Python | System `python` is only the Microsoft Store stub (not installed). **Blender's bundled Python 3.13.13** is used for all asset scripts — sufficient. |
| glTF exporter | Built into Blender (`export_scene.gltf`); Draco and meshoptimizer libraries also present |
| Headless pipeline test | ✅ `assets/blender/scripts/env_check.py` built a mesh + armature + skin + keyframed "Idle" action and exported a GLB in 0.3 s. Parsed result: 3 nodes, 1 mesh, 1 skin, 1 animation. |

### GLB compatibility of the game engine
**The engine cannot load GLB files yet.** Findings:
* No glTF parser, no texture-image loading from GLB, no skinned-mesh shader (vertex layout is position/normal/colour/uv only).
* Animation is procedural per rigid bone; there is no keyframe-clip player.

Required engine work (planned as the first part of Stage 1, gameplay untouched):
1. `engine/gltf.ts` — GLB parser: buffers/accessors, meshes & primitives, PBR base-colour/texture/emissive materials,
   node hierarchy, skins (inverse bind matrices), animations (translation/rotation/scale, LINEAR/STEP, quaternion slerp).
2. Skinned shader variant (`JOINTS_0`/`WEIGHTS_0`, up to ~64 joint matrices as uniforms — well within WebGL2 limits)
   plus a skinned depth shader so characters keep casting shadows.
3. Character integration that **keeps every existing animation state**: the GLB armature uses the same 17 bone names,
   so the procedural animator keeps driving jump/slide/knockdown/victory etc., blended with the baked `Idle`/`Run`
   clips from Blender. Cosmetic attachment points map to the `head`/`body` bones.
4. Fallback: if a GLB fails to load, the current procedural model is used, so the game never breaks.

Export conventions are documented in `assets/README.md` (no Draco, metres, +Z forward, ≤4 weights, ≤15k tris and
≤1 MB per character).

### Backup
`ANIMAL DASH/backups/animal-dash-stage0-20261124-1912.zip` — full source, docs, screenshots and tests (92 files,
11.8 MB; `node_modules` and build output excluded — restore with `npm install` + `npm run build`). Verified by
listing key files inside the archive. (No git on this machine, so zip backups are taken before each stage.)

### Asset folder structure (created)
```
assets/blender/scripts/{common,characters,environments,props}   generation scripts
assets/blender/sources                                           saved .blend files
assets/reference   assets/renders                                art reference, review renders
client/public/models/{characters,environments,props}             exported GLB files served at /models/...
```

### Gameplay changes in Stage 0
None. The only code-adjacent additions are the probe script, folder skeleton, `assets/README.md` and this file.

### Stage 1 plan (pending approval)
1. Engine: GLB loader + skinned rendering + clip player (with procedural fallback) — unit-checked with the probe GLB.
2. `assets/blender/scripts/characters/pug.py`: premium cartoon Pug built in Blender — subdivided organic body, big
   head and expressive glossy eyes with highlights and eyelids, black muzzle/ear mask, forehead wrinkles, curled tail,
   red collar with tag; materials with subtle colour gradients; 17-bone armature with automatic weights;
   `Idle` and `Run` actions; review renders saved to `assets/renders/`.
3. Export `client/public/models/characters/pug.glb`, replace the procedural Pug in character select, lobby, race
   and results; test rendering, scale, animation states, cosmetics and movement in a real race; measure FPS.
4. Report with screenshots and wait for approval.

### Known issues / notes
* Reference art (the image you shared in chat) is not saved as a file in the project; if you can save it to
  `assets/reference/`, it can be used for side-by-side comparison renders.
* Characters produced by script in Blender will be stylised and clean, but sculpted fur-level detail like the
  reference illustration is beyond what procedural Blender modelling achieves; the target is a high-quality cartoon
  game-model look.
