// AnimalActor: a renderable, animated animal instance (model + cosmetics + animator).
import { Renderer, DrawOpts } from '../engine/renderer';
import { Mat4, mat4, multiply, compose } from '../engine/math';
import { AnimalModel, buildAnimal, BONE_COUNT, BONE_PARENT, B } from './animalModels';
import { Animator, AnimInput, P } from '../animations/animator';
import { getCosmetic, CosmeticPart } from './cosmetics';
import { Loadout } from '@shared/progression';
import { ANIMALS } from '@shared/animals';

const modelCache = new Map<string, AnimalModel>();
export function getAnimalModel(gl: WebGL2RenderingContext, animal: number, skin = ''): AnimalModel {
  const key = `${animal}:${skin}`;
  let m = modelCache.get(key);
  if (!m) { m = buildAnimal(gl, animal, skin); modelCache.set(key, m); }
  return m;
}

const tmp = mat4();
const rootM = mat4();

export class AnimalActor {
  readonly animal: number;
  model: AnimalModel;
  anim: Animator;
  world: Mat4[] = Array.from({ length: BONE_COUNT }, () => mat4());
  cosmetics: CosmeticPart[] = [];
  loadout: Loadout | null = null;
  scaleMul = 1;

  constructor(private gl: WebGL2RenderingContext, animal: number, loadout: Loadout | null = null) {
    this.animal = animal;
    this.model = getAnimalModel(gl, animal, loadout?.skin ?? '');
    this.anim = new Animator(this.model.spec);
    this.setLoadout(loadout);
  }

  setLoadout(l: Loadout | null): void {
    this.loadout = l;
    this.model = getAnimalModel(this.gl, this.animal, l?.skin ?? '');
    this.cosmetics = [];
    if (!l) return;
    for (const id of [l.hat, l.glasses, l.outfit, l.accessory]) {
      const c = getCosmetic(this.gl, id, this.model, this.animal);
      if (c) this.cosmetics.push(c);
    }
  }

  update(a: Omit<AnimInput, 'stride'>): void {
    this.anim.update({ ...a, stride: ANIMALS[this.animal].stride });
  }

  /** base: world transform at the animal's feet (origin on the ground, +z forward). */
  computeBones(base: Mat4): void {
    const r = this.anim.root;
    const s = this.model.spec.scale * this.scaleMul;
    const bodyH = this.model.offsets[B.BODY][1] * s;
    // pivot root rotations around the body centre so rolls/flips look natural
    compose(tmp, 0, r.y * s + bodyH, 0, r.pitch, r.yaw, r.roll, s, s, s);
    multiply(rootM, base, tmp);
    compose(tmp, 0, -this.model.offsets[B.BODY][1], 0, 0, 0, 0);
    multiply(rootM, rootM, tmp);
    const pose = this.anim.pose;
    const off = this.model.offsets, rest = this.model.rest;
    for (let b = 0; b < BONE_COUNT; b++) {
      const o = b * P;
      compose(tmp, off[b][0] + pose[o + 3], off[b][1] + pose[o + 4], off[b][2] + pose[o + 5],
        rest[b][0] + pose[o], rest[b][1] + pose[o + 1], rest[b][2] + pose[o + 2], pose[o + 6], pose[o + 7], pose[o + 8]);
      const parent = BONE_PARENT[b];
      multiply(this.world[b], parent < 0 ? rootM : this.world[parent], tmp);
    }
  }

  draw(r: Renderer, opts: DrawOpts = {}): void {
    const meshes = this.model.meshes;
    const o: DrawOpts = { rim: 0.45, spec: this.model.spec.spec, ...opts };
    for (let b = 0; b < BONE_COUNT; b++) {
      const m = meshes[b];
      if (!m) continue;
      if (b === B.TONGUE && this.anim.tongue < 0.05) continue;
      r.draw(m, this.world[b], o);
    }
    for (const c of this.cosmetics) r.draw(c.mesh, this.world[c.bone], { ...o, tint: null, flash: opts.flash });
  }

  /** World position of a bone origin (for particle effects, name tags). */
  bonePos(b: number, out: number[]): number[] {
    const w = this.world[b];
    out[0] = w[12]; out[1] = w[13]; out[2] = w[14];
    return out;
  }
}
